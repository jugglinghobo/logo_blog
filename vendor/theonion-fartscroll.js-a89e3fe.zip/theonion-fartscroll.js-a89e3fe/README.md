# fartscroll.js

Everyone farts. And now your web pages can too.

1. Include "fartscroll.min.js" in your page.
2. Initialize the fartscroll plugin on document.ready:

```javascript
// Fart every 400 pixels scrolled in the document
$(document).fartscroll(); 

// Fart every 800 pixels scrolled in the document
$(document).fartscroll(800);
```
    
More info at [http://theonion.github.io/fartscroll.js/](http://theonion.github.io/fartscroll.js/).
